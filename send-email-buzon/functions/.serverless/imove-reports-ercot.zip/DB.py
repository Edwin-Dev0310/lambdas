import json
from datetime import datetime

from botocore.exceptions import ClientError
import pg8000
import boto3


def get_secret():

    secret_name = "dev/energrid/db"
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        raise e

    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

class DBConnection:

    def connect():
        """
        Crea una conexión a la base de datos
        """
        try:
            secrets = get_secret()
            usuario = secrets["DB_USER"]
            password = secrets["DB_PASSWORD"]
            host = secrets["DB_HOST"]
            port = secrets["DB_PORT"]
            database = secrets["DB_NAME"]
            return pg8000.connect(
                host=host,
                port=int(port),
                database=database,
                user=usuario,
                password=password
            )
        except Exception as e:
            print(e)
            raise Exception(f"Error: {e} ")

    def get_data_from_signal_type(type_v, count, page, filter):

        md = f" 1 = 1 "
        print(filter["category"] != "import", filter["category"] == "import")
        if filter["category"] != "import" and filter["category"] != "export":
            md = "dd.name ilike :type"

        variable = ""
        if filter["filter_osi"] is not None and len(filter["filter_osi"]) > 0:
            md += " and dd.osi_key = ANY(:osi_key)"
        else:
            md += f" and '{filter['filter_osi']}' = '{filter['filter_osi']}'"
        if filter["filter_value"] is not None and filter["filter_value"] != "":
            operator = filter["filter_operator"]
            val = float(filter["filter_value"])
            variable = f" and dd.value::double precision {operator} {val}"

        if filter["filter_search"] is not None and filter["filter_search"] != "":
            md += " and dd.name ILIKE :search_text"
        else:
            md += f" and '1' = '1'"

        format_string = "%Y-%m-%d %H:%M:%S"
        month_start = datetime.strptime(filter["filter_date_start"], format_string).month
        month_end = datetime.strptime(filter["filter_date_end"], format_string).month
        year_start = datetime.strptime(filter["filter_date_start"], format_string).year
        year_end = datetime.strptime(filter["filter_date_end"], format_string).year
        months = []
        years = []
        if month_start != month_end:
            months.append(month_end)
            years.append(year_end)
        if filter["category"] == "import" or filter["category"] == "export":
            if type_v == "":
                md += f" and dd.signal ilike '{filter['category']} %'"
            else:
                md += f" and dd.signal ilike concat('{filter['category']} ', '{type_v}')"
        else:
            md += f" and '{filter['category']}' = '{filter['category']}'"

        buscar = f"{type_v} %"
        text_saarch = f"%{filter["filter_search"]}%"
        rows = []
        total = 0
        sql = "SELECT COUNT(*) FROM ("
        sql += (f"SELECT es_{year_start}_{month_start}.osi_key, es_{year_start}_{month_start}.name, unit_name, d_{year_start}_{month_start}.time, d_{year_start}_{month_start}.value, d_{year_start}_{month_start}.id, "
                f"ty_{year_start}_{month_start}.name as signal, "
                f"cu_{year_start}_{month_start}.name as customer "
                f"FROM ercot.signal as es_{year_start}_{month_start} "
                f"INNER JOIN ercot.station as st_{year_start}_{month_start} ON es_{year_start}_{month_start}.station_id = st_{year_start}_{month_start}.id "
                f"INNER JOIN ercot.data_{year_start}_{month_start} as d_{year_start}_{month_start} on d_{year_start}_{month_start}.signal_id = es_{year_start}_{month_start}.id "
                f"INNER JOIN customer as cu_{year_start}_{month_start} on es_{year_start}_{month_start}.customer_id = cu_{year_start}_{month_start}.id "
                f"LEFT JOIN ercot.signal_type as sty_{year_start}_{month_start} on sty_{year_start}_{month_start}.signal_id = d_{year_start}_{month_start}.signal_id "
                f"LEFT JOIN ercot.type as ty_{year_start}_{month_start} on ty_{year_start}_{month_start}.id = sty_{year_start}_{month_start}.type_id"
               )
        if len(years)>0:
            for month in months:
                for year in years:
                    sql += f" UNION ALL \n"
                    sql += (f"SELECT es_{year}_{month}.osi_key, es_{year}_{month}.name, es_{year}_{month}.unit_name, d_{year}_{month}.time, d_{year}_{month}.value, d_{year}_{month}.id, "
                            f"ty_{year}_{month}.name as signal, "
                            f"cu_{year}_{month}.name as customer "
                            f"FROM ercot.signal as es_{year}_{month} "
                            f"INNER JOIN ercot.station as st_{year}_{month} ON es_{year}_{month}.station_id = st_{year}_{month}.id "
                            f"INNER JOIN ercot.data_{year}_{month} as d_{year}_{month} on d_{year}_{month}.signal_id = es_{year}_{month}.id "
                            f"INNER JOIN customer as cu_{year}_{month} on es_{year}_{month}.customer_id = cu_{year}_{month}.id "
                            f"LEFT JOIN ercot.signal_type as sty_{year}_{month} on sty_{year}_{month}.signal_id = d_{year}_{month}.signal_id "
                            f"LEFT JOIN ercot.type as ty_{year}_{month} on ty_{year}_{month}.id = sty_{year}_{month}.type_id"
                            "\n"
                            )
        sql += f") as dd WHERE {md} {variable} and time between :date_start and :date_end"

        print(sql)
        print(buscar,
              "|",text_saarch,
              "|",filter["filter_osi"],
              "|",filter["filter_date_start"],
              "|",filter["filter_date_end"],
              "|",filter["category"]
              )
        conn = DBConnection.connect()
        print(sql)
        results = conn.run(sql,type=buscar,search_text=f"%{text_saarch}%",osi_key=filter["filter_osi"],date_start=filter["filter_date_start"],date_end=filter["filter_date_end"],category=type_v
                        )

        for row in results:
            total += row[0]

        sql = "SELECT * FROM ("
        sql += (f"SELECT es_{year_start}_{month_start}.osi_key, es_{year_start}_{month_start}.name, unit_name, d_{year_start}_{month_start}.time, d_{year_start}_{month_start}.value, d_{year_start}_{month_start}.id, "
                f"ty_{year_start}_{month_start}.name as signal, "
                f"cu_{year_start}_{month_start}.name as customer "
                f"FROM ercot.signal as es_{year_start}_{month_start} "
                f"INNER JOIN ercot.station as st_{year_start}_{month_start} ON es_{year_start}_{month_start}.station_id = st_{year_start}_{month_start}.id "
                f"INNER JOIN ercot.data_{year_start}_{month_start} as d_{year_start}_{month_start} on d_{year_start}_{month_start}.signal_id = es_{year_start}_{month_start}.id "
                f"INNER JOIN customer as cu_{year_start}_{month_start} on es_{year_start}_{month_start}.customer_id = cu_{year_start}_{month_start}.id "
                f"LEFT JOIN ercot.signal_type as sty_{year_start}_{month_start} on sty_{year_start}_{month_start}.signal_id = d_{year_start}_{month_start}.signal_id "
                f"LEFT JOIN ercot.type as ty_{year_start}_{month_start} on ty_{year_start}_{month_start}.id = sty_{year_start}_{month_start}.type_id"
               )
        if len(years)>0:
            for month in months:
                for year in years:
                    sql += f" UNION ALL \n"
                    sql += (f"SELECT es_{year}_{month}.osi_key, "
                            f"es_{year}_{month}.name, "
                            f"unit_name, "
                            f"d_{year}_{month}.time, "
                            f"d_{year}_{month}.value, "
                            f"d_{year}_{month}.id, "
                            f"ty_{year}_{month}.name as signal, "
                            f"cu_{year}_{month}.name as customer "
                            f"FROM ercot.signal as es_{year}_{month} "
                            f"INNER JOIN ercot.station as st_{year}_{month} ON es_{year}_{month}.station_id = st_{year}_{month}.id "
                            f"INNER JOIN ercot.data_{year}_{month} as d_{year}_{month} on d_{year}_{month}.signal_id = es_{year}_{month}.id "
                            f"INNER JOIN customer as cu_{year}_{month} on es_{year}_{month}.customer_id = cu_{year}_{month}.id "
                            f"LEFT JOIN ercot.signal_type as sty_{year}_{month} on sty_{year}_{month}.signal_id = d_{year}_{month}.signal_id "
                            f"LEFT JOIN ercot.type as ty_{year}_{month} on ty_{year}_{month}.id = sty_{year}_{month}.type_id"
                           )
        sql += f") as dd WHERE {md} {variable} and dd.time between :date_start and :date_end order by dd.time desc limit :count offset ((:page - 1) * :count);"
        print(sql)
        results = conn.run(sql,
                           code=buscar,
                           count=count,
                           page=page,
                           type=buscar,
                           osi_key=filter["filter_osi"],
                           search_text=f"%{text_saarch}%",
                           date_start=filter["filter_date_start"],
                           date_end=filter["filter_date_end"],
                           category=type_v
                           )

        for row in results:
            date_formatt = "%B %d, %Y %H:%M"
            row[3] = row[3].strftime(date_formatt)
            rows.append({
                "id":row[5],
                "osi_key":row[0],
                "name":row[1],
                "unit_name":row[2],
                "local_time":str(row[3]),
                "value":row[4],
                "customer":row[7],
            })
        conn.close()
        return {"total":total,"rows":rows, "pages":total//count + 1}

    def get_catalog(type, subtype, name):
        conn = DBConnection.connect()
        md = "s.name ilike :name"
        if type != "":
            modifier = " and t.name ilike :type"
            md += modifier
        if subtype != "":
            modifier = " and t.name ilike :subtype::text"
            if type == "import" or type == "export":
                modifier = f" and t.name ilike concat('{type} ', :subtype::text)"
            md += modifier
        sql = ("SELECT s.osi_key, s.name, s.unit_name  "
               "FROM ercot.signal AS s "
               "INNER JOIN ercot.signal_type as st ON s.id = st.signal_id "
               "INNER JOIN ercot.type t on st.type_id = t.id "
               f"WHERE  {md} ORDER BY s.name;")
        print(sql)
        results = conn.run(sql, type=f"{type}%", subtype=f"{subtype}", name=f"%{name}%")
        data = []
        for row in results:
            data.append({"osi_key":row[0],"name":row[1],"unit_name":row[2]})
        conn.close()
        return data

    def get_customers():
        conn = DBConnection.connect()
        sql = ("SELECT id, name as customer "
               "FROM customer AS c "
               f"WHERE  status_id = 1 ORDER BY c.name;")
        print(sql)
        results = conn.run(sql)
        data = []
        for row in results:
            data.append({"id":row[0],"customer":row[1]})
        conn.close()
        return data