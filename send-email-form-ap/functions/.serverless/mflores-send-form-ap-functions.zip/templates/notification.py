def get_html_template(name, email, phone, requested_service):
    html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html style="width:100%;font-family: Simplon BP, sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0;">
<custom name="opencounter" type="tracking"/>
<head>
    <meta NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
    <meta NAME="referrer" CONTENT="no-referrer">
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta name="x-apple-disable-message-reformatting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="telephone=no" name="format-detection">
    <title>Ammper</title>
    <!--[if (mso 16)]>
									<style type="text/css">     a {text-decoration: none;}     </style>
									<![endif]-->
    <!--[if gte mso 9]>
									<style>sup { font-size: 100% !important; }</style>
									<![endif]-->
    <!--[if !mso]>
									<!-- -->
    <!--

									<![endif]-->
    <style type="text/css">
        @media only screen and (max-width:600px) {
            p,
            ul li,
            ol li,
            a {
                font-size: 18px !important;
                line-height: 150% !important
            }
            h1 {
                font-size: 25px !important;
                text-align: left;
                line-height: 120%
            }
            h2 {
                font-size: 22px !important;
                text-align: left;
                line-height: 120%
            }
            h3 {
                font-size: 20px !important;
                text-align: left;
                line-height: 120%
            }
            h1 a {
                font-size: 25px !important;
                text-align: left
            }
            h2 a {
                font-size: 22px !important;
                text-align: left
            }
            h3 a {
                font-size: 20px !important;
                text-align: left
            }
			.website {
                    text-align: center !important;
			  font-size: 13px;
			}
            .es-menu td a {
                font-size: 16px !important
            }
            .es-header-body p,
            .es-header-body ul li,
            .es-header-body ol li,
            .es-header-body a {
                font-size: 18px !important
            }
            .es-footer-body p,
            .es-footer-body ul li,
            .es-footer-body ol li,
            .es-footer-body a {
                font-size: 12px !important
            }
            .es-infoblock p,
            .es-infoblock ul li,
            .es-infoblock ol li,
            .es-infoblock a {
                font-size: 18px !important
            }
            *[class="gmail-fix"] {
                display: none !important
            }
            .es-m-txt-c,
            .es-m-txt-c h1,
            .es-m-txt-c h2,
            .es-m-txt-c h3 {
                text-align: center !important
            }
            .es-m-txt-r,
            .es-m-txt-r h1,
            .es-m-txt-r h2,
            .es-m-txt-r h3 {
                text-align: right !important
            }
            .es-m-txt-l,
            .es-m-txt-l h1,
            .es-m-txt-l h2,
            .es-m-txt-l h3 {
                text-align: left !important
            }
            .es-m-txt-r img,
            .es-m-txt-c img,
            .es-m-txt-l img {
                display: inline !important
            }
            .es-button-border {
                display: block !important
            }
            a.es-button {
                font-size: 18px !important;
                display: block !important;
                border-left-width: 0px !important;
                border-right-width: 0px !important
            }
            .es-btn-fw {
                border-width: 10px 0px !important;
                text-align: center !important
            }
            .es-adaptive table,
            .es-btn-fw,
            .es-btn-fw-brdr,
            .es-left,
            .es-right {
                width: 100% !important
            }
            .es-content table,
            .es-header table,
            .es-footer table,
            .es-content,
            .es-footer,
            .es-header {
                width: 100% !important;
                max-width: 600px !important
            }
            .es-adapt-td {
                display: block !important;
                width: 100% !important
            }
            .adapt-img {
                width: 100% !important;
                height: auto !important
					
					 }
            .adapt-img2 {
                width: 80% !important;
                height: auto !important
					
					 }
            .adapt-img3 {
                width: 100px !important;
                height: auto !important;
				align: right;
					
            }
			
			.adapt-td { padding-top: 0px;
				padding-bottom: 0px;
				
			}
			
			
            .adapt-logo {
                width: 40% !important;
                height: auto !important
            }
            .adapt-contact {
                width: 80% !important;
                height: auto !important
			}
            .adapt-icon {
                width: 25% !important;
                height: auto !important
					
            }
            .es-m-p0 {
                padding: 0px !important
            }
            .es-m-p0r {
                padding-right: 0px !important
            }
            .es-m-p0l {
                padding-left: 0px !important
            }
            .es-m-p0t {
                padding-top: 0px !important
            }
            .es-m-p0b {
                padding-bottom: 0 !important
            }
            .es-m-p20b {
                padding-bottom: 20px !important
            }
            .es-mobile-hidden,
            .es-hidden {
                display: none !important
            }
            .es-desk-hidden {
                display: table-row !important;
                width: auto !important;
                overflow: visible !important;
                float: none !important;
                max-height: inherit !important;
                line-height: inherit !important
            }
            .es-desk-menu-hidden {
                display: table-cell !important
					

            }
			
			.adapt-movilcol{
			min-width:250px;
				
			}
			
            table.es-table-not-adapt,
            .esd-block-html table {
                width: auto !important
            }
            table.es-social {
                display: inline-block !important
            }
            table.es-social td {
                display: inline-block !important
            }
        }
        
        #outlook a {
            padding: 0;
        }
        
        .ExternalClass {
            width: 100%;
        }
        
        .ExternalClass,
        .ExternalClass p,
        .ExternalClass span,
        .ExternalClass font,
        .ExternalClass td,
        .ExternalClass div {
            line-height: 100%;
        }
        
        .es-button {
            mso-style-priority: 100 !important;
            text-decoration: none !important;
        }
        
        a[x-apple-data-detectors] {
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }
        
        a .MsoHyperlink .phone {
            mso-style-priority: 100 !important;
            color: #000000 !important;
            color: #000000;
            text-decoration: none !important;
        }
        
        .es-desk-hidden {
            display: none;
            float: left;
            overflow: hidden;
            width: 0;
            max-height: 0;
            line-height: 0;
            mso-hide: all;
        }
    </style>
</head>

<body style="width:100%;font-family: Simplon BP, sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0;">
    <style type="text/css">
        div.preheader {
            display: none !important;
        }
    </style>
    <div class="es-wrapper-color" style="background-color:#F1F1F1;">
        <!--[if gte mso 9]>
										<v:background
											xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
											<v:fill type="tile" color="#f6f6f6"></v:fill>
										</v:background>
										<![endif]-->
        <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center">
            <tr style="border-collapse:collapse;">
                <td valign="top" style="padding:0;Margin:0;">

                    <table class="es-content" cellspacing="0" cellpadding="0" align="center" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;">
                        <tr style="border-collapse:collapse;">
                            <td align="center" style="padding:0;Margin:0;">
                                <table class="es-content-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#FFFFFF;" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                                    <tr style="border-collapse:collapse;">
                                        <td align="left" bgcolor="#f5f7f8" style="padding:0;Margin:0;padding-left:40px;padding-right:40px;background-color:#F5F7F8;">
                                            <table cellpadding="0" cellspacing="0" width="100%" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;">
                                                <tr style="border-collapse:collapse;"></tr>
                                            </table>
                                        </td>
                                    </tr>

								
									<!--INICIO LOGO-->
									
									  <tr style="border-collapse:collapse;">
                                        <td valign="top" align="center" bgcolor="transparent" style="Margin:0;padding:0;background-color:#FFFFFF;">

                                            <table align="center" cellpadding="0" cellspacing="0" class="es-center" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:center;">
                                                <tbody>
                                                    <tr style="border-collapse:collapse;">
                                                        <td valign="top" align="center" class="es-m-p0r" style="padding:0 ;Margin:0;" width="600">
                                                            <table cellpadding="0" cellspacing="0" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;" width="100%">
                                                                <tbody>
                                                                    <tr style="border-collapse:collapse;">
                                                                        <td valign="top" align="center" style="padding:0;margin:0;"><img alt="Ammper" class="adapt-img" src="https://ammper-assets.s3.amazonaws.com/2024/comercial/Formularios/ammpergeneral-head.jpg" width="600" valign="top"/> 

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
																
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
												
                                            </table>
                                        </td>
                                    </tr>
									
									
									<!--Introducción-->
									
									
									<tr style="border-collapse:collapse;">
                                        <td align="center" bgcolor="transparent" style="Margin:0;padding-bottom:10px;padding-top:5px;padding-left:90px;padding-right:90px;">
                                            <p style="Margin:0;line-height:24px;mso-line-height-rule:exactly;font-family: Arial, sans-serif;font-size:16px;font-style:normal;font-weight:normal;color:#4D4E53;text-align:left;">
                                                <strong style="color: #33764b; font-size: 20px;"> <br> !Contacto en Ammper Power!</strong> <br />
                                                <br />
                                                Se ha recibido una nueva solicitud de contacto desde la p&aacute;gina web. Los datos son los siguientes:<br/><br/>
                                                <strong>Nombre:</strong> ${name}<br>
                                                <strong>Email:</strong> ${email}<br>
                                                <strong>Tel&eacute;fono:</strong> ${phone}<br>
                                                <strong>Servicio Solicitado:</strong> ${requested_service}<br><br>
                                                Por favor p&oacute;nganse en contacto a la brevedad.<br><br>
                                            </p>
                                        </td>
                                    </tr>
									<!--Fin introducción-->

								<tr style="border-collapse:collapse;">
                                        <td align="center" bgcolor="transparent" style="Margin:0;padding:0;background-color:#E9E9EA;">

                                            <table align="center" cellpadding="0" cellspacing="0" class="es-center" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:center;">
                                                <tbody>
                                                    <tr style="border-collapse:collapse;">
                                                        <td align="center" class="es-m-p0r" style="padding:0 ;Margin:0;" valign="top" width="600">
                                                            <table cellpadding="0" cellspacing="0" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;" width="100%">
                                                                <tbody>
																	<tr style="border-collapse:collapse;">
                                                                <td align="center" bgcolor="transparent" style="Margin:0;padding-bottom:10px;padding-top:15px;padding-left:30px;padding-right:30px;">
                                                                    <p style="Margin:0;line-height:24px;mso-line-height-rule:exactly;font-family: arial, sans-serif;font-size:12px;font-style:normal;font-weight:normal;color:#33764b;">
                                                                        <a href="https://ammperpower.com/" target="_blank" rel="noopener noreferrer">
                                                                            <strong>ammperpower.com</strong>
                                                                        </a>
                                                                    </p>
                                                                </td>
																	</tr>
                                                            
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
									<!--FIN REDES-->
	</table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>"""

    html = html.replace("${name}", str(name))
    html = html.replace("${email}", str(email))
    html = html.replace("${phone}", str(phone))
    html = html.replace("${requested_service}", str(requested_service))
    
    return html
